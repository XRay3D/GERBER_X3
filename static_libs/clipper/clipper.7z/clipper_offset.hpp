/********************************************************************************
 *                                                                              *
 * Author    :  Angus Johnson                                                   *
 * Version   :  6.4.2                                                           *
 * Date      :  03 October 2022                                                 *
 * Website   :  http://www.angusj.com                                           *
 * Copyright :  Angus Johnson 2010-2017                                         *
 *                                                                              *
 * License   :                                                                  *
 * Use, modification & distribution is subject to Boost Software License Ver 1. *
 * http://www.boost.org/LICENSE_1_0.txt                                         *
 *                                                                              *
 * Attributions:                                                                *
 * The code in this library is an extension of Bala Vatti's clipping algorithm: *
 * "A generic solution to polygon clipping"                                     *
 * Communications of the ACM, Vol 35, Issue 7 (July 1992) pp 56-63.             *
 * http://portal.acm.org/citation.cfm?id=129906                                 *
 *                                                                              *
 * Computer graphics and geometric modeling: implementation and algorithms      *
 * By Max K. Agoston                                                            *
 * Springer; 1 edition (January 4, 2005)                                        *
 * http://books.google.com/books?q=vatti+clipping+agoston                       *
 *                                                                              *
 * See also:                                                                    *
 * "Polygon Offsetting by Computing Winding Numbers"                            *
 * Paper no. DETC2005-85513 pp. 565-575                                         *
 * ASME 2005 International Design Engineering Technical Conferences             *
 * and Computers and Information in Engineering Conference (IDETC/CIE2005)      *
 * September 24-28, 2005 , Long Beach, California, USA                          *
 * http://www.me.berkeley.edu/~mcmains/pubs/DAC05OffsetPolygon.pdf              *
 *                                                                              *
 *******************************************************************************/

#ifndef clipper_hpp
#define clipper_hpp

#define CLIPPER_VERSION "6.4.2"

// use_int32: When enabled 32bit ints are used instead of 64bit ints. This
// improve performance but coordinate values are limited to the range +/- 46340
// #define use_int32

// use_xyz: adds a Z member to IntPoint. Adds a minor cost to perfomance.
// #define use_xyz

// use_lines: Enables line clipping. Adds a very minor cost to performance.
#define use_lines

// use_deprecated: Enables temporary support for the obsolete functions
// #define use_deprecated

#include "mvector.h"

#include <cstdlib>
#include <cstring>
#include <functional>
#include <list>
#include <ostream>
#include <queue>
#include <set>
#include <stdexcept>
#include <stdint.h>
#include <tuple>

#include <QDataStream>
#include <QDebug>
#include <QPolygonF>
#include <QtMath>

#include <numbers>

#include "clipper_base.hpp"

namespace ClipperLib {

class ClipperOffset {
public:
    ClipperOffset(double miterLimit = 2.0, double roundPrecision = 0.25);
    ~ClipperOffset();
    void AddPath(const Path& path, /*JoinType*/ int joinType, EndType endType);
    void AddPaths(const Paths& paths, /*JoinType*/ int joinType, EndType endType);
    void Execute(Paths& solution, double delta);
    void Execute(PolyTree& solution, double delta);
    void Clear();
    double MiterLimit;
    double ArcTolerance;

private:
    Paths m_destPolys;
    Path m_srcPoly;
    Path m_destPoly;
    mvector<DoublePoint> m_normals;
    double m_delta, m_sinA, m_sin, m_cos;
    double m_miterLim, m_StepsPerRad;
    IntPoint m_lowest;
    PolyNode m_polyNodes;

    void FixOrientations();
    void DoOffset(double delta);
    void OffsetPoint(int j, int& k, /*JoinType*/ int jointype);
    void DoSquare(int j, int k, double = {});
    void DoMiter(int j, int k, double r);
    void DoRound(int j, int k, double = {});
};

} // namespace ClipperLib

#endif // clipper_hpp
