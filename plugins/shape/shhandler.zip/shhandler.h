/********************************************************************************
 * Author    :  Damir Bakiev                                                    *
 * Version   :  na                                                              *
 * Date      :  XXXXX XX, 2025                                                  *
 * Website   :  na                                                              *
 * Copyright :  Damir Bakiev 2016-2025                                          *
 * License   :                                                                  *
 * Use, modification & distribution is subject to Boost Software License Ver 1. *
 * http://www.boost.org/LICENSE_1_0.txt                                         *
 ********************************************************************************/
#pragma once

#include "shape.h"
#include <QGraphicsItem>

namespace Shapes {
class Handle final : public QGraphicsItem {
    friend class AbstractShape;
    friend QDataStream& operator<<(QDataStream& stream, const Handle* handle) {
        return stream << handle->pos() << handle->hType();
    }
    friend QDataStream& operator>>(QDataStream& stream, Handle* handle) {
        QPointF pos;
        Handle::Type type;
        stream >> pos >> type;
        qInfo() << pos << type;
        handle->setPos(pos), handle->setHType(type);
        return stream;
    }

public:
    enum Type : int {
        Adder,
        Center,
        Corner,
    };
    explicit Handle(Shapes::AbstractShape* shape, Type type = Corner);
    ~Handle();

    // QGraphicsItem interface
    QRectF boundingRect() const override;
    void paint(QPainter* painter, const QStyleOptionGraphicsItem* option, QWidget* widget) override;
    int type() const override { return Gi::Type::ShHandler; }

    Type hType() const;
    void setHType(Type value);

private:
    Type type_;
    QRectF rect;
    AbstractShape* const shape;
    QPointF lastPos;
    bool pressed{};

protected:
    // QGraphicsItem interface
    void contextMenuEvent(QGraphicsSceneContextMenuEvent* event) override;
    void hoverEnterEvent(QGraphicsSceneHoverEvent* event) override;
    void hoverLeaveEvent(QGraphicsSceneHoverEvent* event) override;

    void mouseMoveEvent(QGraphicsSceneMouseEvent* event) override;
    void mousePressEvent(QGraphicsSceneMouseEvent* event) override;
    void mouseReleaseEvent(QGraphicsSceneMouseEvent* event) override;
};

} // namespace Shapes
